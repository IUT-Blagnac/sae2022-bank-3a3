/**
 * Le package application.control
 * <p>
 * Ce package permet de faire le contrôle des fonctionnalités.
 * </p>
 */
package application.control;