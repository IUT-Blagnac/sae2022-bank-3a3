package application;

import application.control.DailyBankMainFrame;

public class DailyBankApp  {

	/** 
	 * Permet de lancer l'application
	 * @param args argument
	 */
	public static void main(String[] args) {

		DailyBankMainFrame.runApp();

	}
}
