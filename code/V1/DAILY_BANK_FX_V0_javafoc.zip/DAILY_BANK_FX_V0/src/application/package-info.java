/**
 * Le package application
 * <p>
 * Ce package permet le lancement de l'application.
 * </p>
 */
package application;