package application.tools;

public enum EditionMode {
	CREATION, MODIFICATION, SUPPRESSION
}