package application;

import application.control.DailyBankMainFrame;

public class DailyBankApp  {

	/** 
	 * Permet de lancer l'application
	 */
	public static void main(String[] args) {

		DailyBankMainFrame.runApp();

	}
}
